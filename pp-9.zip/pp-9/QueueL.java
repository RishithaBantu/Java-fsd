package project3;
	import java.util.LinkedList;
	import java.util.Queue;
	public class QueueL {
	    public static void main(String[] args) {
	        Queue<String> queue = new LinkedList<>();
	        queue.offer("apple");
	        queue.offer("banana");
	        queue.offer("cherry");
	        System.out.println("Queue after insertion: " + queue);
	        String head = queue.poll();
	        System.out.println("Removed element: " + head);
	        System.out.println("Queue after removal: " + queue);
	    }
	}