package project4;
	public class ExponentialSearch {
	    public static int exponentialSearch(int[] array, int target) {
	        if (array[0] == target) {
	            return 0;
	        }
	        int bound = 1;
	        while (bound < array.length && array[bound] <= target) {
	            bound *= 2;
	        }
	        int left = bound / 2;
	        int right = Math.min(bound, array.length - 1);
	        while (left <= right) {
	            int mid = left + (right - left) / 2;
	            if (array[mid] == target) {
	                return mid; // Return the index where the target is found
	            }

	            if (array[mid] < target) {
	                left = mid + 1;
	            } else {
	                right = mid - 1;
	            }
	        }
	        return -1; // Return -1 if the target is not found
	    }
	    public static void main(String[] args) {
	        int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9};
	        int target = 5;
	        int result = exponentialSearch(numbers, target);
	        if (result == -1) {
	            System.out.println("Target not found in the array.");
	        } else {
	            System.out.println("Target found at index: " + result);
	        }
	    }
	}