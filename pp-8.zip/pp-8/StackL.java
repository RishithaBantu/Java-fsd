package project3;
	import java.util.Stack;

	public class StackL {
	    public static void main(String[] args) {
	        Stack<String> stack = new Stack<>();

	        // push elements onto the stack
	        stack.push("apple");
	        stack.push("banana");
	        stack.push("cherry");
	        System.out.println("Stack after insertion: " + stack);

	        String top = stack.pop();

	        System.out.println("Removed element: " + top);
	        System.out.println("Stack after removal: " + stack);
	    }
	}