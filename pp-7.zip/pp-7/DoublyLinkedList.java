package project3;
	class Node {
	    int data;
	    Node prev;
	    Node next;

	    public Node(int data) {
	        this.data = data;
	        this.prev = null;
	        this.next = null;
	    }
	}

	class DoublyLinkedList {
	    private Node head;

	    public void append(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	        } else {
	            Node current = head;
	            while (current.next != null) {
	                current = current.next;
	            }
	            current.next = newNode;
	            newNode.prev = current;
	        }
	    }

	    public void traverseForward() {
	        Node current = head;
	        while (current != null) {
	            System.out.println(current.data);
	            current = current.next;
	        }
	    }

	    public void traverseBackward() {
	        Node current = head;
	        while (current.next != null) {
	            current = current.next;
	        }
	        while (current != null) {
	            System.out.println(current.data);
	            current = current.prev;
	        }
	    }
	}

