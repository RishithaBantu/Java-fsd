package startp;
public class constructors {
    int number;
    String text;

    // default constructor
    public constructors() {
      int   number;
       String text;
    }

    // parameterized constructor
    public constructors(int num, String txt) {
        number = num;
        text = txt;
    }

    public static void main(String[] args) {
        // creating objects using both constructors
    	constructors obj1 = new constructors();
    	constructors obj2 = new constructors(5, "hello");

       
        System.out.println( obj1.number + " " + obj1.text);
        System.out.println(obj2.number + " " +  obj2.text);
    }
}


