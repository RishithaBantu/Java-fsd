package startp;

public class innerCl2 {
	
	private String msg="Inner Classes";

	void display(){  
		 class Inner{  
			 void msg(){
				 System.out.println(msg);
			 }  
	 }  
	 Inner l=new Inner();  
	 l.msg();  
	}  
	public static void main(String[] args) {
		innerCl2  ob=new innerCl2 ();  
		ob.display();  
		}
	}

		


