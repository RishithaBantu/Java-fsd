package project3;
	import java.util.Arrays;
	public class ArraySort {

	    public static void main(String[] args) {
	        int[] a= {4,3,5,7,9,3,7,0,444,565,32,};
	        Arrays.sort(a);
	        
	        System.out.println("The fourth smallest element is: " + a[3]);
	    }
	}
