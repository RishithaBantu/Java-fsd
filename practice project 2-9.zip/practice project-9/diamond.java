package project2;

interface A {
	   default void abc() {
	    System.out.println("hello");
	   }
	}

	interface B extends A {
	}

	interface C extends A {
	}

	class D implements B, C {
	 
	}

	public class diamond {
	   public static void main(String[] args) {
	      D obj = new D();
	      obj.abc();
	   }
	}


