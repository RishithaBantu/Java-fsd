package startp;

public class arrays {
	public static void main(String[] args)
	{
		//single dimensional array
		int[] a = {20 , 10, 30};
		for(int i = 0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		//multi dimensional array
		int[][] b = {{1,2,3},{1,2,3,4}};
		for(int i = 0;i<b.length;i++)
		{
			for(int j = 0;j<b[i].length;j++)
			{
			System.out.println(b[i][j]);
	     	}	
     	}
   
}
}
