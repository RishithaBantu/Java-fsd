package project4;
	public class InsertionSort {
	    public static void insertionSort(int[] array) {
	        int n = array.length;

	        for (int i = 1; i < n; i++) {
	            int key = array[i];
	            int j = i - 1;
	            while (j >= 0 && array[j] > key) {
	                array[j + 1] = array[j];
	                j--;
	            }
	            array[j + 1] = key;
	        }
	    }
	    public static void main(String[] args) {
	        int[] numbers = {5, 2, 8, 1, 9, 3, 7, 6, 4};
	        insertionSort(numbers);
	        System.out.print("Sorted array: ");
	        for (int number : numbers) {
	            System.out.print(number + " ");
	        }
	    }
	}