package project2;
	import java.io.File;
	import java.io.IOException;
	import java.nio.file.Files;
	public class crudOperations {
	    public static void main(String[] args) {
	        // Create a new file
	        File file = new File("example.txt");
	        try {
	            if (file.createNewFile()) {
	                System.out.println("File created: " + file.getName());
	            } else {
	                System.out.println("File already exists.");
	            }
	        } catch (IOException e) {
	            System.out.println("An error occurred while creating the file.");
	            e.printStackTrace();
	        }

	        // Write to the file
	        try {
	            Files.write(file.toPath(), "This is an example file.".getBytes());
	            System.out.println("Successfully wrote to file.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while writing to the file.");
	            e.printStackTrace();
	        }

	        // Read from the file
	        try {
	            String data = Files.readString(file.toPath());
	            System.out.println("File contents: " + data);
	        } catch (IOException e) {
	            System.out.println("An error occurred while reading from the file.");
	            e.printStackTrace();
	        }

	        // Update the file
	        try {
	            Files.write(file.toPath(), "This is an updated file.".getBytes());
	            System.out.println("Successfully updated file.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while updating the file.");
	            e.printStackTrace();
	        }

	        // Delete the file
	        try {
	            Files.delete(file.toPath());
	            System.out.println("File deleted: " + file.getName());
	        } catch (IOException e) {
	            System.out.println("An error occurred while deleting the file.");
	            e.printStackTrace();
	        }
	    }
	}



