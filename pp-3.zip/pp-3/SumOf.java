package project3;
public class SumOf
  {
    public static void main(String[] args)
    {
        int[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int L = 2;
        int R = 7;
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += a[i];
        }
        
        // print the sum of elements in the range L to R
        System.out.println("The sum of elements in the range [" + L + ", " + R + "] is: " + sum);
    }
}

