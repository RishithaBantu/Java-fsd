package startp;

public class typeCasting {

	public static void main(String[] args) {
		//implicit type casting
		byte a = 45;
		System.out.println(a);
		int b = a;
		System.out.println(b);
		float c = a;
		System.out.println(c);
		double d = a;
		System.out.println(d);
        long l = a;
        System.out.println(l);
        short s = a;
        System.out.println(s);
        //explicit type casting
        double o = 45.5;
        System.out.println(o);
        byte t = (byte)o;
        System.out.println(t);
        int n = (int)o;
        System.out.println(n);
	}

}
