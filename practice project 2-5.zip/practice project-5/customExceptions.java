package project2;


	class MyCustomException extends Exception {
	    public MyCustomException(String errorMessage) {
	        super(errorMessage);
	    }
	}

	public class customExceptions {
	    public static void main(String[] args) {
	        try {
	            throw new MyCustomException("This is a custom exception message.");
	        } catch (MyCustomException e) {
	            System.out.println(e.getMessage());
	        }
	    }
	}


