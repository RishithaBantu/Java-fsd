package project2;


	import java.io.IOException;

	public class Throws {

	    public static void main(String[] args) {
	        try {
	            readFile("file.txt");
	        } catch (IOException e) {
	            System.out.println("error occurred " + e.getMessage());
	        }
	    }

	    public static void readFile(String filename) throws IOException {
	      
	        throw new IOException("\n Unable to read file: " + filename);
	    }

	}


