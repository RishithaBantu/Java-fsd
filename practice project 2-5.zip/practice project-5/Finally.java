package project2;

public class Finally {
	
	    public static void main(String[] args) {
	        try {
	            int a = 10 / 0; 
	            System.out.println("Result: " + a);
	        } catch (ArithmeticException e) {
	            System.out.println("Error: " + e.getMessage());
	        } finally {
	            System.out.println("Inside finally block");
	        }
	        System.out.println("End of program");
	    }
	}


