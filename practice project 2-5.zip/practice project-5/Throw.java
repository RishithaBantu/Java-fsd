package project2;

import java.util.Scanner;

public class Throw {

	    public static void main(String[] args) {
	        try {
	        	Scanner Sc = new Scanner(System.in);
	        	System.out.println("enter the age");
	            int age = Sc.nextInt();
	            if (age < 18) {
	                throw new ArithmeticException("You are still a teenager");
	            }
	            System.out.println("You are no more a teenager");
	        } catch (ArithmeticException e) {
	            System.out.println(e.getMessage());
	        }
	    }
	}


