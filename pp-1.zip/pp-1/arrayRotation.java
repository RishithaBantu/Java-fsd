package project3;

public class arrayRotation {

	    public static void main(String[] args) {
	        int[] a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	        int n = a.length;
	        int k = 5;
	        
	        for (int i = 0; i < k; i++) 
	        {
	           int temp = a[n - 1];
	            for (int j = n - 1; j > 0; j--)
	            {
	                a[j] = a[j - 1];
	            }
	            a[0] = temp;
	        }
	        for (int i = 0; i < n; i++) {
	            System.out.print(a[i] + " ");
	        }
	    }
	}


