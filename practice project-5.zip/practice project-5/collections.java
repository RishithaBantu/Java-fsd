package startp;
import java.util.*;
public class collections {

	    public static void main(String[] args) {
	        // new ArrayList 
	        List<String> list = new ArrayList<>();
	        list.add("apple");
	        list.add("banana");
	        list.add("cherry");
	        System.out.println("Original List:");
	        System.out.println(list);
	        
	        // new HashSet 
	        Set<String> set = new HashSet<>();
	        set.add("apple");
	        set.add("banana");
	        set.add("cherry");
	        System.out.println("Set:");
	        System.out.println(set);
	        
	        //  new TreeSet 
	        SortedSet<String> treeSet = new TreeSet<>();
	        treeSet.add("apple");
	        treeSet.add("banana");
	        treeSet.add("cherry");
	        System.out.println("TreeSet:");
	        System.out.println(treeSet);
	        
	        // new LinkedList 
	        List<String> linkedList = new LinkedList<>();
	        linkedList.add("apple");
	        linkedList.add("banana");
	        linkedList.add("cherry");
	        System.out.println("LinkedList:");
	        System.out.println(linkedList);
	         
	        // new Vector
	        Vector<Integer> vec = new Vector();
		    vec.addElement(15); 
		    vec.addElement(30);
		    vec.addElement(45); 
		    System.out.println("Vector:");
		    System.out.println(vec);
		      
		   
		    
		    
	}

}
