package project2;

public class threads {
	
	    public static void main(String[] args) {
	       
	        Thread thread1 = new Thread() {
	            public void run() {
	                System.out.println("Thread 1 is running.");
	            }
	        };
	        thread1.start();

	        Runnable Run = new Runnable() {
	            public void run() {
	                System.out.println("Thread 2 is running.");
	            }
	        };
	        Thread thread2 = new Thread(Run);
	        thread2.start();
	    }
	}


