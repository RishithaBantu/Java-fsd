package project2;
	class Animal {
	    public void makeSound() {
	        System.out.println("The animal makes a sound");
	    }
	}
	class Dog extends Animal {
	    public void makeSound() {
	        System.out.println("The dog barks");
	    }
	}

	class Cat extends Animal {
	    public void makeSound() {
	        System.out.println("The cat meows");
	    }
	}

	public class polymorphism {
	    public static void main(String[] args) {
	        Animal myAnimal = new Dog();
	        myAnimal.makeSound();
	        myAnimal = new Cat();
	        myAnimal.makeSound();
	    }
	}


