package project2;
	class animals{
	    public void eat() {
	        System.out.println("The animal eats");
	    }
	}

	class puppy extends animals {
	    public void bark() {
	        System.out.println("The dog barks");
	    }
	}

	public class inheritance {
	    public static void main(String[] args) {
	        puppy myDog = new puppy();
	        myDog.eat();
	        myDog.bark();
	    }
	}


