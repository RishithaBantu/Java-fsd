package project2;

public class sleepAndWait { 
	    private static Object OBJ = new Object();   
	  
	    //main() method starts with handling InterruptedException  
	    public static void main(String[] args)
	    throws InterruptedException   
	    { 
	        Thread.sleep(1000);   
	        System.out.println( Thread.currentThread().getName() +   
	        " Thread is woken after 1 second");   
	          
	        synchronized (OBJ)    
	        {     
	            OBJ.wait(1000);   
	            System.out.println(OBJ + " Object is   woken after waiting for 1 second");   
	        }   
	    }   
	}

