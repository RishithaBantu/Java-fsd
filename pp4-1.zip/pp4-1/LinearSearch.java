package project4;
public class LinearSearch {
	    public static int linearSearch(int[] array, int target) {
	        for (int i = 0; i < array.length; i++) {
	            if (array[i] == target) {
	                return i;
	            }
	        }
	        return -1;
	    }

	    public static void main(String[] args) {
	        int[] numbers = {4, 2, 8, 5, 1, 9, 3, 7, 6};
	        int target = 5;
	        
	        int result = linearSearch(numbers, target);
	        
	        if (result != -1) {
	            System.out.println("Target found at index: " + result);
	        } else {
	            System.out.println("Target not found in the array.");
	        }
	    }
	}
